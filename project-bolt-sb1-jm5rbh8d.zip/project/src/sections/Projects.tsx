import React from 'react';
import SectionHeading from '../components/SectionHeading';
import ProjectCard from '../components/ProjectCard';

const Projects: React.FC = () => {
  const projects = [
    {
      title: 'Crime Prediction using Machine Learning',
      date: 'March 2025 – May 2025',
      description: [
        'Developed a machine learning-powered web application to analyze historical crime data and predict crime trends in India.',
        'Implemented data preprocessing, model training, and visualization modules for crime analytics.',
        'Achieved a 40% reduction in data processing time and delivered accurate predictions with interactive visual insights.'
      ],
      techStack: 'Python, Flask, Pandas, Scikit-learn, NumPy, Plotly, HTML, CSS'
    },
    {
      title: 'Cybersecurity – Network Tracking',
      date: 'December 2024 – January 2025',
      description: [
        'Built a Python-based tool to capture and visualize network traffic using geolocation mapping.',
        'Integrated Wireshark packet data with Google Maps API to track IP locations in real time.',
        'Improved network analysis skills and raised awareness of suspicious traffic patterns.'
      ],
      techStack: 'Python, Wireshark, Google Maps API, GeoLiteCity, dpkt, pygeoip'
    },
    {
      title: 'Dictionary Web Application',
      date: 'July 2024 – August 2024',
      description: [
        'Developed a real-time dictionary web application that dynamically fetches and displays word definitions.',
        'Integrated RapidAPI for seamless API communication and implemented efficient DOM manipulation for instant results.',
        'Achieved a 50% reduction in average search latency, significantly enhancing user experience and application responsiveness.'
      ],
      techStack: 'HTML, CSS, JavaScript, RapidAPI'
    }
  ];

  return (
    <section id="projects" className="py-16 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4 md:px-6">
        <SectionHeading 
          title="Projects" 
          subtitle="Here are some of the projects I've worked on"
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {projects.map((project, index) => (
            <div 
              key={index}
              className="transform transition-all duration-500 hover:scale-[1.02]"
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <ProjectCard
                title={project.title}
                date={project.date}
                description={project.description}
                techStack={project.techStack}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;