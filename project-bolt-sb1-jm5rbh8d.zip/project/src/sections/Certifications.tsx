import React from 'react';
import SectionHeading from '../components/SectionHeading';
import { Award } from 'lucide-react';

const Certifications: React.FC = () => {
  const certifications = [
    {
      title: 'Python Training',
      issuer: 'Spoken Tutorial Project, IIT Bombay'
    },
    {
      title: 'Java Fundamentals',
      issuer: 'Oracle Academy'
    },
    {
      title: 'AI and ML',
      issuer: 'Oracle Academy'
    },
    {
      title: 'IT Essentials',
      issuer: 'Cisco Networking Academy'
    },
    {
      title: 'Git',
      issuer: 'Microsoft Learn'
    },
    {
      title: 'RDBMS',
      issuer: 'Spoken Tutorial, IIT Bombay'
    },
    {
      title: 'Introduction to Networks',
      issuer: 'Cisco Networking Academy'
    },
    {
      title: 'Database Programming with SQL',
      issuer: 'Oracle Academy'
    }
  ];

  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-800">
      <div className="container mx-auto px-4 md:px-6">
        <SectionHeading 
          title="Certifications" 
          subtitle="Professional courses and certifications I've completed"
        />
        
        <div className="max-w-4xl mx-auto mt-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {certifications.map((cert, index) => (
              <div 
                key={index} 
                className="bg-white dark:bg-gray-900 rounded-lg shadow-md p-6 flex items-start transform transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
              >
                <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-full">
                  <Award className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100">
                    {cert.title}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {cert.issuer}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Certifications;