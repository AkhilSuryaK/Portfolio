import React, { useEffect, useRef, useState } from 'react';
import SectionHeading from '../components/SectionHeading';
import SkillBar from '../components/SkillBar';
import { Code, Database, Globe, Lightbulb } from 'lucide-react';

const Skills: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      {
        root: null,
        rootMargin: '0px',
        threshold: 0.3,
      }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  const programmingSkills = [
    { name: 'Python', level: 85 },
    { name: 'Java', level: 80 },
    { name: 'C', level: 75 },
    { name: 'JavaScript', level: 75 },
  ];

  const webSkills = [
    { name: 'HTML/CSS', level: 80 },
    { name: 'React', level: 70 },
    { name: 'Node.js', level: 65 },
  ];

  const databaseSkills = [
    { name: 'SQL', level: 80 },
    { name: 'MySQL', level: 75 },
  ];

  const softSkills = [
    { name: 'Problem Solving', level: 90 },
    { name: 'Communication', level: 85 },
    { name: 'Teamwork', level: 85 },
    { name: 'Adaptability', level: 80 },
  ];

  return (
    <section id="skills" className="py-16 bg-gray-50 dark:bg-gray-800" ref={sectionRef}>
      <div className="container mx-auto px-4 md:px-6">
        <SectionHeading 
          title="Technical Skills" 
          subtitle="Here are some of the technologies and skills I've worked with"
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
          <div className={`bg-white dark:bg-gray-900 rounded-lg shadow-md p-6 transform transition-all duration-700 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <div className="flex items-center mb-6">
              <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-lg">
                <Code className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="ml-4 text-xl font-semibold text-gray-800 dark:text-gray-100">
                Programming
              </h3>
            </div>
            {programmingSkills.map((skill) => (
              <SkillBar
                key={skill.name}
                name={skill.name}
                level={isVisible ? skill.level : 0}
                color="bg-blue-600 dark:bg-blue-500"
              />
            ))}
          </div>
          
          <div className={`bg-white dark:bg-gray-900 rounded-lg shadow-md p-6 transform transition-all duration-700 delay-100 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <div className="flex items-center mb-6">
              <div className="bg-indigo-100 dark:bg-indigo-900 p-3 rounded-lg">
                <Globe className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
              </div>
              <h3 className="ml-4 text-xl font-semibold text-gray-800 dark:text-gray-100">
                Web Development
              </h3>
            </div>
            {webSkills.map((skill) => (
              <SkillBar
                key={skill.name}
                name={skill.name}
                level={isVisible ? skill.level : 0}
                color="bg-indigo-600 dark:bg-indigo-500"
              />
            ))}
          </div>
          
          <div className={`bg-white dark:bg-gray-900 rounded-lg shadow-md p-6 transform transition-all duration-700 delay-200 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <div className="flex items-center mb-6">
              <div className="bg-purple-100 dark:bg-purple-900 p-3 rounded-lg">
                <Database className="w-6 h-6 text-purple-600 dark:text-purple-400" />
              </div>
              <h3 className="ml-4 text-xl font-semibold text-gray-800 dark:text-gray-100">
                Databases
              </h3>
            </div>
            {databaseSkills.map((skill) => (
              <SkillBar
                key={skill.name}
                name={skill.name}
                level={isVisible ? skill.level : 0}
                color="bg-purple-600 dark:bg-purple-500"
              />
            ))}
          </div>
          
          <div className={`bg-white dark:bg-gray-900 rounded-lg shadow-md p-6 transform transition-all duration-700 delay-300 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <div className="flex items-center mb-6">
              <div className="bg-emerald-100 dark:bg-emerald-900 p-3 rounded-lg">
                <Lightbulb className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
              </div>
              <h3 className="ml-4 text-xl font-semibold text-gray-800 dark:text-gray-100">
                Soft Skills
              </h3>
            </div>
            {softSkills.map((skill) => (
              <SkillBar
                key={skill.name}
                name={skill.name}
                level={isVisible ? skill.level : 0}
                color="bg-emerald-600 dark:bg-emerald-500"
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;