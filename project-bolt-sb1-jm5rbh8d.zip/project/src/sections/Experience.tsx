import React from 'react';
import SectionHeading from '../components/SectionHeading';
import ExperienceCard from '../components/ExperienceCard';

const Experience: React.FC = () => {
  const experiences = [
    {
      role: 'Data Visualization Analyst',
      company: 'Forage (TCS) Virtual Experience',
      date: 'December 2024 – January 2025',
      description: [
        'Completed a simulation involving creating data visualizations for Tata Consultancy Services.',
        'Prepared questions for a meeting with client senior leadership.',
        'Created visuals for data analysis to help executives with effective decision making.'
      ]
    },
    {
      role: 'Web Development Intern',
      company: 'Prodigy InfoTech',
      date: 'July 2024 – August 2024',
      description: [
        'Developed a real-time dictionary web application that dynamically fetches and displays word definitions.',
        'Integrated RapidAPI for seamless API communication and implemented efficient DOM manipulation for instant results.',
        'Achieved a 50% reduction in average search latency, significantly enhancing user experience and application responsiveness.'
      ]
    }
  ];

  return (
    <section id="experience" className="py-16 bg-gray-50 dark:bg-gray-800">
      <div className="container mx-auto px-4 md:px-6">
        <SectionHeading 
          title="Work Experience" 
          subtitle="My professional journey so far"
        />
        
        <div className="max-w-3xl mx-auto mt-12">
          {experiences.map((exp, index) => (
            <ExperienceCard
              key={index}
              role={exp.role}
              company={exp.company}
              date={exp.date}
              description={exp.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;