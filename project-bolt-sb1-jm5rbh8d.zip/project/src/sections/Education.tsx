import React from 'react';
import SectionHeading from '../components/SectionHeading';
import { Briefcase, GraduationCap } from 'lucide-react';

const Education: React.FC = () => {
  const education = [
    {
      degree: 'Bachelor of Engineering (B.E.) – Computer Science and Engineering',
      institution: 'Matrusri Engineering College, Hyderabad',
      date: 'November 2021 – June 2025 (Expected)',
      grade: 'CGPA: 8.02'
    },
    {
      degree: 'Class 12 (Intermediate – MPC)',
      institution: 'Narayana Junior College, Hyderabad',
      date: 'June 2019 – April 2021',
      grade: 'Percentage: 92.4%'
    },
    {
      degree: 'Class 10 (SSC)',
      institution: 'Narayana Olympiad School, Hyderabad',
      date: 'June 2018 – April 2019',
      grade: 'CGPA: 9.8'
    }
  ];

  return (
    <section id="education" className="py-16 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4 md:px-6">
        <SectionHeading 
          title="Education" 
          subtitle="My academic qualifications"
        />
        
        <div className="max-w-3xl mx-auto mt-12">
          {education.map((edu, index) => (
            <div key={index} className="relative pl-8 pb-10 last:pb-0">
              {/* Timeline dot */}
              <div className="absolute left-0 top-0 w-4 h-4 bg-blue-600 dark:bg-blue-400 rounded-full z-10"></div>
              
              {/* Timeline line */}
              {index !== education.length - 1 && (
                <div className="absolute left-2 top-0 bottom-0 w-[1px] bg-gray-300 dark:bg-gray-600 z-0"></div>
              )}
              
              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg shadow-md p-6 ml-4">
                <div className="flex flex-col space-y-1 mb-4">
                  <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100">
                    {edu.degree}
                  </h3>
                  <div className="flex items-center">
                    <GraduationCap className="w-4 h-4 text-gray-600 dark:text-gray-400 mr-2" />
                    <p className="text-md text-gray-700 dark:text-gray-300">
                      {edu.institution}
                    </p>
                  </div>
                </div>
                
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center mt-4">
                  <div className="flex items-center">
                    <Briefcase className="w-4 h-4 text-gray-600 dark:text-gray-400 mr-2" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {edu.date}
                    </p>
                  </div>
                  <p className="text-sm font-medium bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-1 rounded mt-2 md:mt-0">
                    {edu.grade}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Education;