import React from 'react';
import SectionHeading from '../components/SectionHeading';

const About: React.FC = () => {
  return (
    <section id="about" className="py-16 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4 md:px-6">
        <SectionHeading title="About Me" />
        
        <div className="max-w-3xl mx-auto">
          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg shadow-md p-6 md:p-8">
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
              Aspiring Software Developer and motivated Computer Science undergraduate. Proficient in Python, Java, C, SQL, 
              and Web Technologies with hands-on experience in building data-driven applications and real-time tools.
            </p>
            
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
              Passionate about problem-solving and leveraging technology to deliver impactful solutions. 
              Committed to continuous learning and professional growth. Looking for opportunities to contribute 
              to innovative projects and expand my technical expertise.
            </p>
          </div>
          
          <div className="mt-12">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg shadow-md p-6">
                <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4">
                  Contact Information
                </h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="font-medium text-gray-700 dark:text-gray-300 min-w-[100px]">Location:</span>
                    <span className="text-gray-600 dark:text-gray-400">Hyderabad, India</span>
                  </li>
                  <li className="flex items-start">
                    <span className="font-medium text-gray-700 dark:text-gray-300 min-w-[100px]">Phone:</span>
                    <a href="tel:+918328679535" className="text-blue-600 dark:text-blue-400 hover:underline">
                      +91 8328679535
                    </a>
                  </li>
                  <li className="flex items-start">
                    <span className="font-medium text-gray-700 dark:text-gray-300 min-w-[100px]">Email:</span>
                    <a href="mailto:akhilsurupaka@gmail.com" className="text-blue-600 dark:text-blue-400 hover:underline">
                      akhilsurupaka@gmail.com
                    </a>
                  </li>
                </ul>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg shadow-md p-6">
                <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4">
                  Personal Details
                </h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="font-medium text-gray-700 dark:text-gray-300 min-w-[120px]">Graduation:</span>
                    <span className="text-gray-600 dark:text-gray-400">June 2025 (Expected)</span>
                  </li>
                  <li className="flex items-start">
                    <span className="font-medium text-gray-700 dark:text-gray-300 min-w-[120px]">LinkedIn:</span>
                    <a 
                      href="https://www.linkedin.com/in/akhilsurya" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-600 dark:text-blue-400 hover:underline"
                    >
                      linkedin.com/in/akhilsurya
                    </a>
                  </li>
                  <li className="flex items-start">
                    <span className="font-medium text-gray-700 dark:text-gray-300 min-w-[120px]">GitHub:</span>
                    <a 
                      href="https://github.com/AkhilSuryaK" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-600 dark:text-blue-400 hover:underline"
                    >
                      github.com/AkhilSuryaK
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;