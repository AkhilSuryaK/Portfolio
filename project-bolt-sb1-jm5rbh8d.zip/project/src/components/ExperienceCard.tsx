import React from 'react';

interface ExperienceCardProps {
  role: string;
  company: string;
  date: string;
  description: string[];
}

const ExperienceCard: React.FC<ExperienceCardProps> = ({ role, company, date, description }) => {
  return (
    <div className="relative pl-8 pb-8">
      {/* Timeline dot */}
      <div className="absolute left-0 top-0 w-4 h-4 bg-blue-600 dark:bg-blue-400 rounded-full z-10"></div>
      
      {/* Timeline line */}
      <div className="absolute left-2 top-0 bottom-0 w-[1px] bg-gray-300 dark:bg-gray-600 z-0"></div>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 ml-4">
        <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-4">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100">{role}</h3>
          <span className="text-sm bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-1 rounded mt-2 md:mt-0">
            {date}
          </span>
        </div>
        
        <p className="text-md font-medium text-gray-700 dark:text-gray-300 mb-4">
          {company}
        </p>
        
        <div className="text-gray-700 dark:text-gray-300 space-y-2">
          {description.map((point, index) => (
            <p key={index} className="text-sm">• {point}</p>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ExperienceCard;