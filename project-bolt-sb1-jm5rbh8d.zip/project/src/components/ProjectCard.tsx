import React, { useState } from 'react';

interface ProjectCardProps {
  title: string;
  date: string;
  description: string[];
  techStack: string;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ title, date, description, techStack }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div 
      className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg transform hover:-translate-y-1"
    >
      <div className="p-6">
        <div className="flex justify-between items-start">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100">{title}</h3>
          <span className="text-sm bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-1 rounded">
            {date}
          </span>
        </div>
        
        <div className="mt-4">
          <h4 className="text-sm font-semibold text-gray-600 dark:text-gray-400 mb-2">
            Tech Stack:
          </h4>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            {techStack}
          </p>
        </div>
        
        <div className="mt-4">
          <div className={`text-gray-700 dark:text-gray-300 space-y-2 ${isExpanded ? '' : 'line-clamp-3'}`}>
            {description.map((point, index) => (
              <p key={index} className="text-sm">• {point}</p>
            ))}
          </div>
          
          {description.length > 2 && (
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="mt-3 text-sm font-medium text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 focus:outline-none"
            >
              {isExpanded ? 'Show less' : 'Read more'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;